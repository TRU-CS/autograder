import unittest
import ctypes
from gradescope_utils.autograder_utils.decorators import weight

# Load the compiled shared library
lib = ctypes.CDLL("./banking.so")

# Define function prototypes for pass-by-reference changes
lib.deposit.argtypes = [ctypes.POINTER(ctypes.c_double), ctypes.c_double]
lib.deposit.restype = None  # No return value since balance is modified directly

lib.withdraw.argtypes = [ctypes.POINTER(ctypes.c_double), ctypes.c_double]
lib.withdraw.restype = None  # No return value since balance is modified directly

lib.calculateCompoundInterest.argtypes = [ctypes.c_double, ctypes.c_double, ctypes.c_int, ctypes.c_int]
lib.calculateCompoundInterest.restype = ctypes.c_double  # Still returns a value

class TestBankingSystem(unittest.TestCase):

    @weight(5)
    def test_deposit(self):
        """Deposit $500 should update balance to $1500.00."""
        balance = ctypes.c_double(1000.00)
        lib.deposit(ctypes.byref(balance), 500.00)  # Pass balance by reference
        self.assertAlmostEqual(balance.value, 1500.00, places=2, msg="Deposit function failed!")

    @weight(5)
    def test_withdraw(self):
        """Withdraw $200 should update balance to $800.00."""
        balance = ctypes.c_double(1000.00)
        lib.withdraw(ctypes.byref(balance), 200.00)  # Pass balance by reference
        self.assertAlmostEqual(balance.value, 800.00, places=2, msg="Withdraw function failed!")

    @weight(5)
    def test_insufficient_funds(self):
        """Withdrawal of more than balance should leave balance unchanged."""
        balance = ctypes.c_double(1000.00)
        lib.withdraw(ctypes.byref(balance), 2000.00)  # Attempt to withdraw more than balance
        self.assertAlmostEqual(balance.value, 1000.00, places=2, msg="Balance should remain unchanged!")

    @weight(5)
    def test_compound_interest(self):
        """Calculate compound interest for $1000 at 5% for 2 years (compounded yearly)."""
        result = lib.calculateCompoundInterest(1000.00, 0.05, 2, 1)
        self.assertAlmostEqual(result, 1102.50, places=2, msg="Compound interest calculation incorrect!")

if __name__ == "__main__":
    unittest.main()