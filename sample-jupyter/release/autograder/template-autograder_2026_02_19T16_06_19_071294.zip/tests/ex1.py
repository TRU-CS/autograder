OK_FORMAT = True

test = {   'name': 'ex1',
    'points': 5,
    'suites': [   {   'cases': [   {'code': ">>> assert sum(1, 2) == 3, f'unexpected {sum(1, 2)}'\n", 'hidden': False, 'locked': False},
                                   {'code': ">>> assert sum(0, 0) == 0, f'unexpected {sum(0, 0)}'\n", 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
