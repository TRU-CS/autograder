OK_FORMAT = True

test = {   'name': 'ex2',
    'points': 5,
    'suites': [   {   'cases': [   {'code': ">>> assert df is not None, 'df does not exist'\n", 'hidden': False, 'locked': False},
                                   {'code': ">>> assert df.shape == (150, 5), f'unexpected {df.shape}'\n", 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
