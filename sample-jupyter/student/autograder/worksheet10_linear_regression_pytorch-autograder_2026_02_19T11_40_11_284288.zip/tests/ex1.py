OK_FORMAT = True

test = {   'name': 'ex1',
    'points': 10,
    'suites': [   {   'cases': [   {   'code': '>>> import torch\n'
                                               '>>> import torch.nn as nn\n'
                                               ">>> assert isinstance(X_tensor, torch.Tensor), 'X_tensor must be a torch.Tensor'\n"
                                               ">>> assert isinstance(Y_tensor, torch.Tensor), 'Y_tensor must be a torch.Tensor'\n"
                                               ">>> assert X_tensor.shape == (4, 1), f'Unexpected X_tensor shape: {X_tensor.shape}'\n"
                                               ">>> assert Y_tensor.shape == (4, 1), f'Unexpected Y_tensor shape: {Y_tensor.shape}'\n"
                                               ">>> assert isinstance(model, nn.Module), 'model must be a torch.nn.Module'\n"
                                               ">>> assert isinstance(criterion, nn.MSELoss), 'criterion should be nn.MSELoss'\n"
                                               ">>> assert isinstance(optimizer, torch.optim.Optimizer), 'optimizer must be a torch optimizer'\n"
                                               ">>> assert isinstance(predictions, torch.Tensor), 'predictions must be a torch.Tensor'\n"
                                               ">>> assert predictions.shape == (4, 1), f'Unexpected predictions shape: {predictions.shape}'\n",
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> with torch.no_grad():\n'
                                               '...     train_mse = torch.mean((model(X_tensor) - Y_tensor) ** 2).item()\n'
                                               ">>> assert train_mse < 0.03, f'Model fit is too weak. MSE={train_mse:.5f}'\n"
                                               '>>> with torch.no_grad():\n'
                                               '...     pred_5 = model(torch.tensor([[5.0]], dtype=torch.float32)).item()\n'
                                               ">>> assert 4.2 <= pred_5 <= 4.8, f'Prediction at x=5.0 is out of expected range: {pred_5:.4f}'\n",
                                       'hidden': True,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
