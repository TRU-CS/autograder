OK_FORMAT = True

test = {   'name': 'ex2',
    'points': 10,
    'suites': [   {   'cases': [   {   'code': ">>> assert isinstance(loss_histories, dict), 'loss_histories must be a dictionary'\n"
                                               ">>> assert isinstance(final_losses, dict), 'final_losses must be a dictionary'\n"
                                               ">>> assert set(loss_histories.keys()) == set(learning_rates), 'loss_histories keys must match learning_rates'\n"
                                               ">>> assert set(final_losses.keys()) == set(learning_rates), 'final_losses keys must match learning_rates'\n"
                                               ">>> assert all((len(v) == epochs for v in loss_histories.values())), 'Each loss history must have length equal to epochs'\n"
                                               ">>> assert best_lr in learning_rates, 'best_lr must be one of learning_rates'\n",
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> for lr in learning_rates:\n'
                                               "...     assert loss_histories[lr][-1] < loss_histories[lr][0], f'Loss did not decrease for lr={lr}'\n"
                                               '>>> expected_best = min(final_losses, key=final_losses.get)\n'
                                               ">>> assert best_lr == expected_best, 'best_lr should correspond to the minimum final loss'\n"
                                               ">>> assert final_losses[0.1] < final_losses[0.001], 'Higher learning rate should converge faster here within fixed epochs'\n"
                                               ">>> assert final_losses[best_lr] < 0.05, f'Best final loss is too high: {final_losses[best_lr]:.5f}'\n",
                                       'hidden': True,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
